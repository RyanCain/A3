package com.company;

import java.io.Serializable;

/**
 * Created by Ryan on 09/04/2017.
 */
public class Books implements Serializable {
    private String title, author, publisher;
    private int yearPublished;
    private Genres genre;

    public Books(){
        title="Title";
        author="Author";
        publisher="Publisher";
        setGenre(Genres.OTHER);
        yearPublished=2017;
    }
    public Books(String title, String author, String publisher, String genre, String yearPublished ){
        this.title=title;
        this.author=author;
        this.publisher=publisher;
        this.genre= Genres.valueOf(genre.toUpperCase().trim());
        this.yearPublished=Integer.parseInt(yearPublished);
//        this.yearPublished=yearPublished;
    }
    public void setGenre(Genres genre){
        this.genre= genre;
    }
    public void printBook(){
        System.out.println("\n-----------------------------------------\n");
        System.out.println("Title: "+title+"\nAuthor: "+author+"\nPublisher: "+publisher+"\nGenre: "+genre+"\nYear Published: "+yearPublished);
    }
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getYearPublished() {
        return yearPublished;
    }

    public Genres getGenre() {
        return genre;
    }

}
