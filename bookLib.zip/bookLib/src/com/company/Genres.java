package com.company;

/**
 * Created by Ryan on 09/04/2017.
 */
public enum Genres {
    SCI_FI,FANTASY, ACTION, TEXTBOOK, ROMANCE, CRIME, THRILLER, HORROR, DRAMA, TRADGEDY, NON_FICTION, BIOGRAPHY,OTHER;
}

