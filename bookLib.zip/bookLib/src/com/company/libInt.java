package com.company;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Ryan on 09/04/2017.
 */
public class libInt {

    JPanel rootPanel;
    private JButton btnAdd;
    private JButton btnEdit;
    private JButton btnDelete;
    private JComboBox cmbSort;
    private JTable tblBooks;
    private JScrollPane spTable;
    private JButton btnSave;
    public static ArrayList<Books> bookList=new ArrayList<>();
//        btnAdd.addActionListener(new ActionListener() {
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            System.out.println("Add");
//        }
//    });
//        btnEdit.addActionListener(new ActionListener() {
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            System.out.println("Edit");
//        }
//    });
//        btnDelete.addActionListener(new ActionListener() {
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            System.out.println("Delete");
//        }
//    });
//        cmbSort.addActionListener(new ActionListener() {
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            System.out.println("Property Change");
//        }
//    });

    public libInt() {

        btnAdd.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            while (true) {
                String title = JOptionPane.showInputDialog(rootPanel,
                        "Book Title", null).trim();
                if (title.equals("")) {
                    break;
                }
                String author = JOptionPane.showInputDialog(rootPanel,
                        "Book Author", null).trim();
                if (author.equals("")) {
                    break;
                }
                String pub = JOptionPane.showInputDialog(rootPanel,
                        "Book Publisher", null).trim();
                if (pub.equals("")) {
                    break;
                }
                String[] genres = {"Sci_Fi", "Fantasy", "Action", "Textbook", "Romance", "Crime", "Thriller", "Horror", "Drama", "Tradgedy", "Non_Fiction", "Biography", "Other"};
                String genre = (String) JOptionPane.showInputDialog(rootPanel, "Book Genre", "Add Book", JOptionPane.QUESTION_MESSAGE, null, genres, genres[0]);//http://www.java2s.com/Tutorial/Java/0240__Swing/Todisplaysadialogwithalistofchoicesinadropdownlistbox.htm
                String year;
                while (true) {
                    year = JOptionPane.showInputDialog(rootPanel, "Year Published", null).trim();
                    try{
                        int number=Integer.parseInt(year);
                        break;
                    }catch(NumberFormatException numError){
                        JOptionPane.showMessageDialog(rootPanel, "Incorrect value error. Please use numbers \nError: "+numError);
                    }
                }
                Books newBook= new Books(title,author,pub,genre,year);
                bookList.add(newBook);
                DefaultTableModel model=(DefaultTableModel) tblBooks.getModel();

                model.addRow(new Object[]{
                        newBook.getTitle(),
                        newBook.getAuthor(),
                        newBook.getPublisher(),
                        newBook.getGenre(),
                        newBook.getYearPublished()
                });
                break;
            }
        }
    });
        btnEdit.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            while(true){
                String bookTitle=JOptionPane.showInputDialog(rootPanel, "Title of the book to edit", null).trim();
                Books editBook=new Books();
                try{
                    for(Books book: bookList){
                        if(bookTitle.equalsIgnoreCase(book.getTitle())){
                            bookList.indexOf(book);
                            editBook=book;
                        }
                    }
                }catch(Exception err){
                    JOptionPane.showMessageDialog(rootPanel, "Book not found\nError: "+err);
                }




                String title = JOptionPane.showInputDialog(rootPanel,
                        "Book Title", editBook.getTitle()).trim();
                if (title.equals("")) {
                    break;
                }
                String author = JOptionPane.showInputDialog(rootPanel,
                        "Book Author", editBook.getAuthor()).trim();
                if (author.equals("")) {
                    break;
                }
                String pub = JOptionPane.showInputDialog(rootPanel,
                        "Book Publisher", editBook.getPublisher()).trim();
                if (pub.equals("")) {
                    break;
                }
                String[] genres = {"Sci_Fi", "Fantasy", "Action", "Textbook", "Romance", "Crime", "Thriller", "Horror", "Drama", "Tradgedy", "Non_Fiction", "Biography", "Other"};
                int genInd=0;
                for(int n=0; n<genres.length;n++){
                    String tempGen=editBook.getGenre().toString();
                    if(tempGen.equalsIgnoreCase(genres[n])){
                        genInd=n;
                    }
                }
                String genre = (String) JOptionPane.showInputDialog(rootPanel, "Book Genre", "Add Book", JOptionPane.QUESTION_MESSAGE, null, genres, genres[genInd]);
                String year;
                while (true) {
                    year = JOptionPane.showInputDialog(rootPanel, "Year Published", editBook.getYearPublished()).trim();
                    try{
                        int number=Integer.parseInt(year);
                        break;
                    }catch(NumberFormatException numError){
                        JOptionPane.showMessageDialog(rootPanel, "Incorrect value error. Please use numbers \nError: "+numError);
                    }
                }
                bookList.remove(editBook);
                Books newBook= new Books(title,author,pub,genre,year);
                bookList.add(newBook);
                DefaultTableModel model=(DefaultTableModel) tblBooks.getModel();
                for(int i=0;i<model.getRowCount();i++){
                    if(model.getValueAt(i, 0).equals(editBook.getTitle())){
                        model.removeRow(i);
                    }
                }
                model.addRow(new Object[]{
                        newBook.getTitle(),
                        newBook.getAuthor(),
                        newBook.getPublisher(),
                        newBook.getGenre(),
                        newBook.getYearPublished()
                });
                break;
            }
        }
    });
        btnDelete.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String bookTitle=JOptionPane.showInputDialog(rootPanel, "Title of the book to Delete", null).trim();
            Books delete=new Books();
            while(true) {
                try {
                    for (Books book : bookList) {
                        if (bookTitle.equalsIgnoreCase(book.getTitle())) {
                            bookList.indexOf(book);
                            delete = book;
                        }
                    }
                } catch (Exception err) {
                    JOptionPane.showMessageDialog(rootPanel, "Book not found\nError: " + err);
                }
                bookList.remove(delete);
                DefaultTableModel model=(DefaultTableModel) tblBooks.getModel();
                for(int i=0;i<model.getRowCount();i++){
                    if(model.getValueAt(i, 0).equals(delete.getTitle())){
                        model.removeRow(i);
                    }
                }
                break;
            }
        }
    });
        cmbSort.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String selectedItem= cmbSort.getSelectedItem().toString();
            if(selectedItem.equalsIgnoreCase("title")){
                BookTitleComparator comparator=new BookTitleComparator();
                Collections.sort(bookList, comparator);
            } else if(selectedItem.equalsIgnoreCase("Author")){
                BookAuthorComparator comparator=new BookAuthorComparator();
                Collections.sort(bookList, comparator);
            } else if(selectedItem.equalsIgnoreCase("Publisher")){
                BookPublisherComparator comparator=new BookPublisherComparator();
                Collections.sort(bookList, comparator);
            } else if(selectedItem.equalsIgnoreCase("Genre")){
                BookGenreComparator comparator=new BookGenreComparator();
                Collections.sort(bookList, comparator);
            } else if(selectedItem.equalsIgnoreCase("Year")){
                BookYearComparator comparator=new BookYearComparator();
                Collections.sort(bookList, comparator);
            }
            DefaultTableModel model=(DefaultTableModel) tblBooks.getModel();
            model.setRowCount(0);
            Object rows[]=new Object[5];
            for(Books book:bookList){
                book.printBook();
                rows[0]=book.getTitle();
                rows[1]=book.getAuthor();
                rows[2]=book.getPublisher();
                rows[3]=book.getGenre();
                rows[4]=book.getYearPublished();
                model.addRow(rows);
                System.out.print("Row Done");
            }
        }
    });
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    writeBooks(bookList);
                    JOptionPane.showMessageDialog(rootPanel,"Saved to Hard Drive");
                }catch(Exception error){
                    JOptionPane.showMessageDialog(rootPanel,"Error Saving to hard drive\nError: "+error);
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("MyTable");
        frame.setContentPane(new libInt().rootPanel);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
        try{
            readBooks(bookList);
        }catch (Exception e){
            System.out.println("Cannot Read from hard drive");
        }
        Object[] columnNames={"Title", "Author", "Publisher", "Genre", "Year Published"};
        DefaultTableModel uiTable=new DefaultTableModel(0, columnNames.length);
        uiTable.setColumnIdentifiers(columnNames);

        Object rows[]=new Object[5];
        for(Books book:bookList){
            book.printBook();
            rows[0]=book.getTitle();
            rows[1]=book.getAuthor();
            rows[2]=book.getPublisher();
            rows[3]=book.getGenre();
            rows[4]=book.getYearPublished();
            uiTable.addRow(rows);
            System.out.print("Row Done");
        }
        tblBooks=new JTable(uiTable);

    }
    private void updateTable(){


    }

    private static void readBooks(ArrayList<Books> bookList) throws Exception{
//        bookList.clear();
        FileInputStream fileInputStream=new FileInputStream("bookList.dat");
        ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
        try{
            System.out.println(1);
            while(true){
                System.out.println(2);
                try {
                    Books bookSingle = (Books) objectInputStream.readObject();
                    bookList.add(bookSingle);
                }catch(Exception e){
                    System.out.println(e);
                    break;
                }

            }
        } catch(Exception e){
            System.out.println("File Read");
        }
        objectInputStream.close();
        for(Books book:bookList){
            book.printBook();
        }
    }

    private static void writeBooks(ArrayList<Books> books) throws Exception{
        try{
            FileOutputStream fileOutputStream=new FileOutputStream("bookList.dat");
            ObjectOutputStream objectOutputStream=new ObjectOutputStream(fileOutputStream);
            for(Books book:books){
                objectOutputStream.writeObject(book);
            }
        } catch (Exception ex){
            System.out.println("Cannot write to file. Error: "+ex);
        }
    }

}
