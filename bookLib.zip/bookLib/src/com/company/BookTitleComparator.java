package com.company;

import java.util.Comparator;

/**
 * Created by Ryan on 18/04/2017.
 */
public class BookTitleComparator implements Comparator<Books>{
    public int compare(Books book1, Books book2){
        return book1.getTitle().compareToIgnoreCase(book2.getTitle());
    }
}
