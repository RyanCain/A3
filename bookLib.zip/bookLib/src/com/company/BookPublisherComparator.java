package com.company;

import java.util.Comparator;

/**
 * Created by Ryan on 18/04/2017.
 */
public class BookPublisherComparator implements Comparator<Books>{
    public int compare(Books book1, Books book2){
        return book1.getPublisher().compareToIgnoreCase(book2.getPublisher());
    }
}
